import React from 'react';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Operator Dashboard</h1>
        <p>Phase 8.0 Frontend</p>
      </header>
    </div>
  );
}

export default App;
